chrome.runtime.onInstalled.addListener(() => {
  console.log('ChatGPT Auto-Dictate installed');
});